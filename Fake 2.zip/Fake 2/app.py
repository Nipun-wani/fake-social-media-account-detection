import streamlit as st
import pandas as pd
import numpy as np
import pickle
from fetch_profile import fetch_instagram_profile, extract_features_from_profile, save_profile_picture
from pathlib import Path
import base64
import matplotlib.pyplot as plt

# === Set Page Config FIRST ===
st.set_page_config(page_title="Instagram Fake Profile Detector", layout="wide")

# === Optional: Set Background Image ===
def set_background(image_file_path: str):
    with open(image_file_path, "rb") as image_file:
        encoded = base64.b64encode(image_file.read()).decode()
    css = f"""
    <style>
    .stApp {{
        background-image: url("data:image/jpg;base64,{encoded}");
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)

# Load background image
set_background("rb.jpg")

# === Load models and scaler ===
xgb_model = pickle.load(open("model/xgb_model.pkl", "rb"))
rf_model = pickle.load(open("model/rf_model.pkl", "rb"))
scaler = pickle.load(open("model/scaler.pkl", "rb"))
feature_columns = pickle.load(open("model/feature_order.pkl", "rb"))

# === Streamlit UI ===
st.title("🔍 Instagram Fake Profile Detection")

username = st.text_input("Enter Instagram Username:")
analyze_button = st.button("Analyze Profile")

if analyze_button and username:
    profile = fetch_instagram_profile(username)

    if profile is None:
        st.error("❌ Could not fetch profile data.")
    else:
        profile_pic = save_profile_picture(profile.get("profile_pic_url", ""), username)
        bio = profile.get("biography", "")

        if profile_pic:
            st.image(profile_pic, width=100, caption="📸 Profile Picture")

        st.markdown(f"### 👤 {profile.get('full_name', '')}")
        st.markdown(f"📝 Bio: _{bio}_")

        # === Basic Profile Information ===
        st.markdown("#### 📌 Profile Details:")
        st.markdown(f"- 👤 **Username:** `{profile.get('username', '')}`")
        st.markdown(f"- 🆔 **User ID:** `{profile.get('id', '-')}`")
        st.markdown(f"- 🔐 **Private Account:** {'Yes' if profile.get('is_private', 0) else 'No'}")
        st.markdown(f"- 🙋‍♂️ **Followers:** `{profile.get('follower_count', 0):,}`")
        st.markdown(f"- 🤝 **Following:** `{profile.get('following_count', 0):,}`")
        st.markdown(f"- 🧠 **Username Length:** `{len(profile.get('username', ''))}`")
        st.markdown(f"- 📝 **Biography Length:** `{len(bio)}`")

        features = extract_features_from_profile(profile)

        # === Derived features ===
        features["follower_following_ratio"] = features.get("edge_followed_by", 0) / (features.get("edge_follow", 0) + 1)
        features["following_to_follower_ratio"] = features.get("edge_follow", 0) / (features.get("edge_followed_by", 0) + 1)

        # === Fill missing feature columns ===
        for col in feature_columns:
            if col not in features:
                features[col] = 0

        feature_df = pd.DataFrame([features])[feature_columns]
        scaled_features = scaler.transform(feature_df)

        try:
            # === Model Predictions ===
            xgb_proba = xgb_model.predict_proba(scaled_features)[0]
            rf_proba = rf_model.predict_proba(scaled_features)[0]

            xgb_pred = int(np.argmax(xgb_proba))
            rf_pred = int(np.argmax(rf_proba))

            xgb_conf = np.max(xgb_proba)
            rf_conf = np.max(rf_proba)

            best_model = "XGBoost" if xgb_conf >= rf_conf else "Random Forest"
            best_pred = xgb_pred if best_model == "XGBoost" else rf_pred
            best_proba = xgb_proba if best_model == "XGBoost" else rf_proba

            def display_prediction(name, pred, proba, is_best=False):
                label = "✅ Genuine" if pred == 0 else "❌ Fake"
                style = "**" if is_best else ""
                st.markdown(f"{style}{name} Prediction:{style} {label}")
                st.markdown(f"• Confidence - Genuine: `{proba[0]*100:.2f}%`, Fake: `{proba[1]*100:.2f}%`")

            st.subheader("🧠 Prediction Results")
            display_prediction("XGBoost", xgb_pred, xgb_proba, best_model == "XGBoost")
            display_prediction("Random Forest", rf_pred, rf_proba, best_model == "Random Forest")

            st.success(f"📌 Based on confidence, **{best_model}** is selected.")
            st.info(f"🔎 Final Decision: **{'✅ Genuine' if best_pred == 0 else '❌ Fake'}** (Confidence: `{max(best_proba)*100:.2f}%`)")

            # === Dynamic Per-Profile Evaluation Metrics ===
            with st.expander("📈 Evaluation Metrics for this Profile"):
                st.markdown("### ✅ Per-Profile Prediction Report")

                results_df = pd.DataFrame({
                    "Model": ["XGBoost", "Random Forest", "Final Decision"],
                    "Predicted Label": [
                        "Genuine" if xgb_pred == 0 else "Fake",
                        "Genuine" if rf_pred == 0 else "Fake",
                        "Genuine" if best_pred == 0 else "Fake"
                    ],
                    "Confidence (Genuine %)": [
                        f"{xgb_proba[0]*100:.2f}%",
                        f"{rf_proba[0]*100:.2f}%",
                        f"{best_proba[0]*100:.2f}%"
                    ],
                    "Confidence (Fake %)": [
                        f"{xgb_proba[1]*100:.2f}%",
                        f"{rf_proba[1]*100:.2f}%",
                        f"{best_proba[1]*100:.2f}%"
                    ]
                })
                st.dataframe(results_df)

            # === Function to plot probability heatmap dynamically ===
            def plot_probability_heatmap(proba, model_name):
                fig, ax = plt.subplots(figsize=(1.2, 0.4), dpi=200)  # ultra small & sharp

                ax.imshow([proba], cmap="Blues", aspect="auto")

                # Labels
                ax.set_xticks([0, 1])
                ax.set_xticklabels(["Genuine", "Fake"], fontsize=6)
                ax.set_yticks([])

                # Annotate inside
                for i, v in enumerate(proba):
                    ax.text(i, 0, f"{v*100:.0f}%", ha="center", va="center",
                            color="black", fontsize=6, fontweight="bold")

                ax.set_title(model_name, fontsize=7, pad=1)

                # Remove extra space
                fig.tight_layout(pad=0.2)
                fig.subplots_adjust(left=0.25, right=0.95, top=0.75, bottom=0.15)

                for spine in ax.spines.values():
                    spine.set_visible(False)

                # 🔑 Force small display on frontend
                st.pyplot(fig, clear_figure=True, use_container_width=False)

            # === Dynamic Probability Visualization ===
            with st.expander("📊 Model Prediction Probability Heatmaps"):
                plot_probability_heatmap(xgb_proba, "XGBoost")
                plot_probability_heatmap(rf_proba, "Random Forest")

            with st.expander("🔍 Debug Info"):
                st.write("Input Features:")
                st.write(feature_df)
                st.write("Scaled Features:")
                st.write(scaled_features)

        except Exception as e:
            st.error(f"Prediction Error: {e}")
